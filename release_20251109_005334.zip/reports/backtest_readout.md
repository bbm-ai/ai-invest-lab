# Backtest Readout — based on strategies of 2025-11-08

| Symbol | Pos | Final | MaxDD | Sharpe | Bars |
|---|---:|---:|---:|---:|---:|
| DIA | 0.00 | 1.0000 | 0.000 | 0.000 | 1256 |
| QQQ | 1.00 | 2.1128 | 0.356 | 0.049 | 1256 |
| SPY | 0.00 | 1.0000 | 0.000 | 0.000 | 1256 |