# 📅 Daily Report — 2025-11-08
- Pipeline: OK | Last Run: 2025-11-08T05:35:09.924453
- Costs: 0.00

| date | symbol | rec | pos_size | confidence |
|-----:|:------:|:---:|---------:|-----------:|
| 2025-11-08 | SPY | HOLD | 0.20 | 0.65 |