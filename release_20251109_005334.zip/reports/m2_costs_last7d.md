# LLM Routing & Cost (calls) — last 7 days

| Day | Provider | Calls | OK | ERROR | SKIP |
|---|---|---:|---:|---:|---:|
| 2025-11-09 | claude | 2 | 0 | 0 | 2 |
| 2025-11-09 | gemini | 6 | 6 | 0 | 0 |
| 2025-11-08 | gemini | 5 | 3 | 0 | 2 |
| 2025-11-08 | groq | 2 | 0 | 1 | 1 |
