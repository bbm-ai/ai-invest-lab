# 🧪 Backtest Report (SMA 10/30) — 2025-11-08

- Period: 2024-09-13 → 2025-11-07
- Return: -9.24%
- Sharpe: -0.77
- Max Drawdown: -18.16%

## Notes
合成資料僅供驗證框架，非投資建議。
