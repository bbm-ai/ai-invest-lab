# Day 17 — Ops Summary (2025-11-08)

## Healthcheck
```json
{"ok":true,"day":"2025-11-08","strategies":3,"report":"/home/bbm/ai-invest-lab/reports/strategy_2025-11-08.md","log":"/home/bbm/ai-invest-lab/logs/daily_2025-11-08.log"}}
```

## Backup

- Status: FAIL

## Latest Backups
```bash
daily_2025-11-08_231812.sha256
daily_2025-11-08_231812.sqlite3.gz
daily_2025-11-08_231532.sha256
daily_2025-11-08_231532.sqlite3.gz
daily_2025-11-08_231348.sha256
daily_2025-11-08_231348.sqlite3.gz
daily_2025-11-08_230352.sha256
daily_2025-11-08_230352.sqlite3.gz
```
