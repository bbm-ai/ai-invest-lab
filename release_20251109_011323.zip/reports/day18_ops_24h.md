# Day 18 — 24h Ops Report

_Generated at: 2025-11-09T01:13:23_

## LLM Routing & Cost (last 24h)

| Provider | Calls | OK | ERROR | SKIP |
|---|---|---|---|---|
| gemini | 242 | 73 | 71 | 98 |
| groq | 171 | 57 | 65 | 49 |
| claude | 8 | 0 | 0 | 8 |

### Route mix

| Route | Count |
|---|---|
| primary | 306 |
| backup | 107 |
| escalated | 8 |

### Error samples

| Error(head) | Count |
|---|---|
| simulated timeout | 76 |
| simulated dns | 22 |
| groq simulated timeout | 18 |
| simulated 429 | 8 |
| gemini simulated timeout | 7 |
| groq simulated 429 | 2 |
| gemini simulated dns failure | 2 |
| Error code: 404 - {'error': {'message': 'The model `gpt-oss: | 1 |

## Strategies (last 24h)

Total rows: **3**

| Date | Symbol | Rec | Size | Conf |
|---|---|---|---|---|
| 2025-11-08 | DIA | HOLD | 0.0 | 0.59 |
| 2025-11-08 | QQQ | BUY | 1.0 | 0.59 |
| 2025-11-08 | SPY | HOLD | 0.0 | 0.59 |

## Backups (latest 10 files)

| File | Bytes | MTime | within_24h |
|---|---|---|---|
| daily_2025-11-08_231812.sqlite3.gz | 18631 | 2025-11-08T23:18:12 | True |
| daily_2025-11-08_231532.sqlite3.gz | 18631 | 2025-11-08T23:15:32 | True |
| daily_2025-11-08_231348.sqlite3.gz | 18631 | 2025-11-08T23:13:48 | True |
| daily_2025-11-08_230352.sqlite3.gz | 18631 | 2025-11-08T23:03:52 | True |

