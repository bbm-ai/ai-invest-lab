# Milestone 1 — 驗收摘要（2025-11-08）

- CSV：SPY/QQQ/DIA 欄位正確，已去除第二行多餘標頭。
- News：RSS 匯入 70 則（去重 by url_hash）。
- Sentiments：±1 天視窗共 28 筆。
- Git：打上 `v0.1-milestone1` tag；main 已推。
- 下一步：Day 8 啟動 LLM API 整合與 APIRouter（Dry-Run），Day 9 接入真實 API + Failover。
