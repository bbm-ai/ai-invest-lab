# Day 16 — Failover/Retry Summary

## llm_costs — 最近 200 筆（觀察 OK/ERROR/SKIP 與 route）
```sql
2025-11-09 02:42:24|news_summary|groq|ERROR|backup|simulated timeout
2025-11-09 02:42:24|strategy_synthesis|groq|ERROR|backup|groq simulated timeout
2025-11-09 02:42:22|strategy_synthesis|gemini|ERROR|primary|simulated timeout
2025-11-09 02:42:20|news_summary|groq|ERROR|backup|simulated timeout
2025-11-09 02:42:20|tech_summary|groq|ERROR|backup|groq simulated timeout
2025-11-09 02:42:18|tech_summary|gemini|ERROR|primary|simulated timeout
2025-11-09 02:42:16|news_summary|gemini|ERROR|backup|simulated timeout
2025-11-09 02:42:16|news_summary|gemini|ERROR|backup|gemini simulated timeout
2025-11-09 02:42:14|news_summary|groq|ERROR|primary|simulated timeout
2025-11-09 02:42:12|news_summary|groq|ERROR|backup|simulated timeout
2025-11-09 02:42:12|strategy_synthesis|groq|ERROR|backup|groq simulated timeout
2025-11-09 02:42:10|strategy_synthesis|gemini|ERROR|primary|simulated timeout
2025-11-09 02:42:08|news_summary|groq|ERROR|backup|simulated timeout
2025-11-09 02:42:08|tech_summary|groq|ERROR|backup|groq simulated timeout
2025-11-09 02:42:06|tech_summary|gemini|ERROR|primary|simulated timeout
2025-11-09 02:42:04|news_summary|gemini|ERROR|backup|simulated timeout
2025-11-09 02:42:04|news_summary|gemini|ERROR|backup|gemini simulated timeout
2025-11-09 02:42:02|news_summary|groq|ERROR|primary|simulated timeout
2025-11-09 02:42:00|tech_summary|gemini|ERROR|primary|simulated dns
2025-11-09 02:42:00|news_summary|groq|OK|backup|
2025-11-09 02:42:00|strategy_synthesis|gemini|ERROR|primary|simulated dns
2025-11-09 02:42:00|news_summary|groq|OK|backup|
2025-11-09 02:42:00|news_summary|groq|OK|primary|
2025-11-09 02:42:00|tech_summary|gemini|ERROR|primary|simulated dns
2025-11-09 02:42:00|news_summary|groq|OK|backup|
2025-11-09 02:42:00|strategy_synthesis|gemini|OK|primary|
2025-11-09 02:41:59|strategy_synthesis|gemini|ERROR|primary|simulated timeout
2025-11-09 02:41:59|news_summary|groq|OK|backup|
2025-11-09 02:41:59|news_summary|groq|OK|primary|
2025-11-09 02:41:57|tech_summary|gemini|ERROR|primary|simulated timeout
2025-11-09 02:41:57|news_summary|groq|OK|backup|
2025-11-09 02:41:55|strategy_synthesis|gemini|ERROR|primary|simulated timeout
2025-11-09 02:41:55|news_summary|groq|OK|backup|
2025-11-09 02:41:55|news_summary|groq|OK|primary|
2025-11-09 02:41:53|tech_summary|gemini|ERROR|primary|simulated timeout
2025-11-09 02:41:53|news_summary|groq|OK|backup|
2025-11-09 02:41:51|news_summary|gemini|OK|backup|
2025-11-09 02:41:51|tech_summary|gemini|OK|primary|
2025-11-09 02:41:51|strategy_synthesis|gemini|OK|primary|
2025-11-09 02:41:51|news_summary|groq|ERROR|primary|simulated 429
2025-11-09 02:41:51|news_summary|gemini|OK|backup|
2025-11-09 02:41:51|tech_summary|gemini|OK|primary|
2025-11-09 02:41:51|strategy_synthesis|gemini|OK|primary|
2025-11-09 02:41:51|news_summary|groq|ERROR|primary|simulated 429
2025-11-09 02:41:51|news_summary|gemini|OK|backup|
2025-11-09 02:41:51|tech_summary|gemini|OK|primary|
2025-11-09 02:41:51|strategy_synthesis|gemini|OK|primary|
2025-11-09 02:41:51|news_summary|groq|OK|primary|
2025-11-09 02:41:50|news_summary|groq|ERROR|primary|simulated timeout
2025-11-09 02:41:48|news_summary|groq|ERROR|primary|simulated timeout
2025-11-09 02:41:48|news_summary|gemini|OK|backup|
2025-11-09 02:41:48|tech_summary|gemini|OK|primary|
2025-11-09 02:41:48|strategy_synthesis|gemini|OK|primary|
2025-11-09 02:41:46|news_summary|groq|ERROR|backup|simulated timeout
2025-11-09 02:41:46|strategy_synthesis|groq|ERROR|backup|groq simulated timeout
2025-11-09 02:41:46|news_summary|groq|OK|primary|
2025-11-09 02:41:46|tech_summary|gemini|OK|primary|
2025-11-09 02:41:46|strategy_synthesis|gemini|OK|primary|
2025-11-09 02:41:46|news_summary|groq|OK|primary|
2025-11-09 02:41:46|tech_summary|gemini|OK|primary|
2025-11-09 02:41:46|strategy_synthesis|gemini|OK|primary|
2025-11-09 02:41:44|strategy_synthesis|gemini|ERROR|primary|simulated timeout
2025-11-09 02:41:42|news_summary|groq|ERROR|backup|simulated timeout
2025-11-09 02:41:42|tech_summary|groq|ERROR|backup|groq simulated timeout
2025-11-09 02:41:40|tech_summary|gemini|ERROR|primary|simulated timeout
2025-11-09 02:41:38|news_summary|groq|ERROR|primary|simulated timeout
2025-11-09 02:41:38|news_summary|gemini|ERROR|backup|simulated dns
2025-11-09 02:41:38|news_summary|gemini|ERROR|backup|gemini simulated dns failure
2025-11-09 02:41:36|strategy_synthesis|groq|ERROR|backup|groq simulated timeout
2025-11-09 02:41:35|news_summary|groq|ERROR|backup|simulated timeout
2025-11-09 02:41:33|strategy_synthesis|gemini|ERROR|primary|simulated timeout
2025-11-09 02:41:31|news_summary|groq|ERROR|backup|simulated timeout
2025-11-09 02:41:31|tech_summary|groq|ERROR|backup|groq simulated timeout
2025-11-09 02:41:29|tech_summary|gemini|ERROR|primary|simulated timeout
2025-11-09 02:41:27|news_summary|gemini|ERROR|backup|simulated timeout
2025-11-09 02:41:27|news_summary|gemini|ERROR|backup|gemini simulated timeout
2025-11-09 02:41:25|news_summary|groq|ERROR|primary|simulated timeout
2025-11-09 02:41:23|strategy_synthesis|gemini|ERROR|primary|simulated timeout
2025-11-09 02:41:23|news_summary|groq|OK|backup|
2025-11-09 02:41:23|news_summary|groq|OK|primary|
2025-11-09 02:41:23|tech_summary|gemini|ERROR|primary|simulated dns
2025-11-09 02:41:23|news_summary|groq|OK|backup|
2025-11-09 02:41:23|strategy_synthesis|gemini|ERROR|primary|simulated dns
2025-11-09 02:41:23|news_summary|groq|OK|backup|
2025-11-09 02:41:23|news_summary|groq|OK|primary|
2025-11-09 02:41:23|tech_summary|gemini|ERROR|primary|simulated dns
2025-11-09 02:41:23|news_summary|groq|OK|backup|
2025-11-09 02:41:23|strategy_synthesis|gemini|ERROR|primary|simulated dns
2025-11-09 02:41:23|news_summary|groq|OK|backup|
2025-11-09 02:41:21|tech_summary|gemini|ERROR|primary|simulated timeout
2025-11-09 02:41:21|news_summary|groq|OK|backup|
2025-11-09 02:41:19|strategy_synthesis|gemini|ERROR|primary|simulated timeout
2025-11-09 02:41:19|news_summary|groq|OK|backup|
2025-11-09 02:41:19|news_summary|groq|OK|primary|
2025-11-09 02:41:17|tech_summary|gemini|ERROR|primary|simulated timeout
2025-11-09 02:41:17|news_summary|groq|OK|backup|
2025-11-09 02:41:15|tech_summary|gemini|OK|primary|
2025-11-09 02:41:15|strategy_synthesis|gemini|OK|primary|
2025-11-09 02:41:15|news_summary|groq|OK|primary|
2025-11-09 02:41:14|news_summary|groq|ERROR|primary|simulated timeout
2025-11-09 02:41:14|news_summary|gemini|OK|backup|
2025-11-09 02:41:14|tech_summary|gemini|OK|primary|
2025-11-09 02:41:14|strategy_synthesis|gemini|OK|primary|
2025-11-09 02:41:14|news_summary|groq|OK|primary|
2025-11-09 02:41:14|tech_summary|gemini|OK|primary|
2025-11-09 02:41:14|strategy_synthesis|gemini|OK|primary|
2025-11-09 02:41:14|news_summary|groq|ERROR|primary|simulated 429
2025-11-09 02:41:14|news_summary|gemini|OK|backup|
2025-11-09 02:41:12|news_summary|groq|ERROR|primary|simulated timeout
2025-11-09 02:41:12|news_summary|gemini|OK|backup|
2025-11-09 02:41:12|tech_summary|gemini|OK|primary|
2025-11-09 02:41:12|strategy_synthesis|gemini|OK|primary|
2025-11-09 02:41:10|strategy_synthesis|gemini|ERROR|primary|simulated timeout
2025-11-09 02:41:10|news_summary|groq|ERROR|backup|simulated 429
2025-11-09 02:41:10|strategy_synthesis|groq|ERROR|backup|groq simulated 429
2025-11-09 02:41:08|news_summary|groq|ERROR|backup|simulated timeout
2025-11-09 02:41:08|tech_summary|groq|ERROR|backup|groq simulated timeout
2025-11-09 02:41:06|news_summary|gemini|ERROR|backup|simulated timeout
2025-11-09 02:41:06|news_summary|gemini|ERROR|backup|gemini simulated timeout
2025-11-09 02:41:06|tech_summary|gemini|ERROR|primary|simulated dns
2025-11-09 02:41:04|news_summary|groq|ERROR|primary|simulated timeout
2025-11-09 02:41:02|news_summary|groq|ERROR|backup|simulated timeout
2025-11-09 02:41:02|strategy_synthesis|groq|ERROR|backup|groq simulated timeout
2025-11-09 02:41:00|strategy_synthesis|gemini|ERROR|primary|simulated timeout
2025-11-09 02:40:58|news_summary|groq|ERROR|backup|simulated timeout
2025-11-09 02:40:58|tech_summary|groq|ERROR|backup|groq simulated timeout
2025-11-09 02:40:56|tech_summary|gemini|ERROR|primary|simulated timeout
2025-11-09 02:40:54|news_summary|gemini|ERROR|backup|simulated timeout
2025-11-09 02:40:54|news_summary|gemini|ERROR|backup|gemini simulated timeout
2025-11-09 02:40:52|news_summary|groq|ERROR|primary|simulated 429
2025-11-09 02:40:51|news_summary|groq|ERROR|backup|simulated timeout
2025-11-09 02:40:51|strategy_synthesis|groq|ERROR|backup|groq simulated timeout
2025-11-09 02:40:49|strategy_synthesis|gemini|ERROR|primary|simulated timeout
2025-11-09 02:40:47|news_summary|groq|ERROR|backup|simulated timeout
2025-11-09 02:40:47|tech_summary|groq|ERROR|backup|groq simulated timeout
2025-11-09 02:40:45|tech_summary|gemini|ERROR|primary|simulated timeout
2025-11-09 02:40:43|news_summary|gemini|ERROR|backup|simulated timeout
2025-11-09 02:40:43|news_summary|gemini|ERROR|backup|gemini simulated timeout
2025-11-09 02:40:41|news_summary|groq|ERROR|primary|simulated timeout
2025-11-09 02:40:39|news_summary|groq|ERROR|backup|simulated timeout
2025-11-09 02:40:39|strategy_synthesis|groq|ERROR|backup|groq simulated timeout
2025-11-09 02:40:37|strategy_synthesis|gemini|ERROR|primary|simulated timeout
2025-11-09 02:40:35|news_summary|groq|ERROR|backup|simulated timeout
2025-11-09 02:40:35|tech_summary|groq|ERROR|backup|groq simulated timeout
2025-11-09 02:40:33|tech_summary|gemini|ERROR|primary|simulated timeout
2025-11-09 02:40:31|news_summary|gemini|ERROR|backup|simulated timeout
2025-11-09 02:40:31|news_summary|gemini|ERROR|backup|gemini simulated timeout
2025-11-09 02:40:29|news_summary|groq|ERROR|primary|simulated timeout
2025-11-09 02:40:27|strategy_synthesis|gemini|ERROR|primary|simulated timeout
2025-11-09 02:40:27|news_summary|groq|OK|backup|
2025-11-09 02:40:27|news_summary|groq|OK|primary|
2025-11-09 02:40:27|tech_summary|gemini|ERROR|primary|simulated dns
2025-11-09 02:40:27|news_summary|groq|OK|backup|
2025-11-09 02:40:27|strategy_synthesis|gemini|ERROR|primary|simulated dns
2025-11-09 02:40:27|news_summary|groq|OK|backup|
2025-11-09 02:40:27|news_summary|groq|OK|primary|
2025-11-09 02:40:27|tech_summary|gemini|ERROR|primary|simulated dns
2025-11-09 02:40:27|news_summary|groq|OK|backup|
2025-11-09 02:40:27|strategy_synthesis|gemini|ERROR|primary|simulated dns
2025-11-09 02:40:27|news_summary|groq|OK|backup|
2025-11-09 02:40:25|tech_summary|gemini|ERROR|primary|simulated timeout
2025-11-09 02:40:25|news_summary|groq|OK|backup|
2025-11-09 02:40:23|news_summary|groq|OK|primary|
2025-11-09 02:40:22|tech_summary|gemini|ERROR|primary|simulated timeout
2025-11-09 02:40:22|news_summary|groq|OK|backup|
2025-11-09 02:40:22|strategy_synthesis|gemini|OK|primary|
2025-11-09 02:40:20|news_summary|groq|ERROR|primary|simulated timeout
2025-11-09 02:40:20|news_summary|gemini|OK|backup|
2025-11-09 02:40:20|tech_summary|gemini|OK|primary|
2025-11-09 02:40:20|strategy_synthesis|gemini|OK|primary|
2025-11-09 02:40:20|news_summary|groq|ERROR|primary|simulated 429
2025-11-09 02:40:20|news_summary|gemini|OK|backup|
2025-11-09 02:40:20|tech_summary|gemini|OK|primary|
2025-11-09 02:40:20|strategy_synthesis|gemini|OK|primary|
2025-11-09 02:40:20|news_summary|groq|ERROR|primary|simulated 429
2025-11-09 02:40:20|news_summary|gemini|OK|backup|
2025-11-09 02:40:20|tech_summary|gemini|OK|primary|
2025-11-09 02:40:20|strategy_synthesis|gemini|OK|primary|
2025-11-09 02:40:20|news_summary|groq|OK|primary|
2025-11-09 02:40:18|news_summary|groq|ERROR|primary|simulated timeout
2025-11-09 02:40:18|news_summary|gemini|OK|backup|
2025-11-09 02:40:18|tech_summary|gemini|OK|primary|
2025-11-09 02:40:18|strategy_synthesis|gemini|OK|primary|
2025-11-09 02:40:15|news_summary|groq|ERROR|backup|simulated timeout
2025-11-09 02:40:15|strategy_synthesis|groq|ERROR|backup|groq simulated timeout
2025-11-09 02:40:15|news_summary|groq|OK|primary|
2025-11-09 02:40:15|tech_summary|gemini|ERROR|primary|simulated dns
2025-11-09 02:40:15|news_summary|groq|OK|backup|
2025-11-09 02:40:15|strategy_synthesis|gemini|ERROR|primary|simulated dns
2025-11-09 02:40:15|news_summary|groq|OK|backup|
2025-11-09 02:40:15|news_summary|groq|OK|primary|
2025-11-09 02:40:15|tech_summary|gemini|ERROR|primary|simulated dns
2025-11-09 02:40:15|news_summary|groq|OK|backup|
2025-11-09 02:40:15|strategy_synthesis|gemini|ERROR|primary|simulated dns
2025-11-09 02:40:15|news_summary|groq|OK|backup|
2025-11-09 02:40:13|strategy_synthesis|gemini|ERROR|primary|simulated timeout
2025-11-09 02:40:11|news_summary|groq|ERROR|backup|simulated timeout
2025-11-09 02:40:11|tech_summary|groq|ERROR|backup|groq simulated timeout
2025-11-09 02:40:09|tech_summary|gemini|ERROR|primary|simulated timeout
2025-11-09 02:40:07|news_summary|groq|ERROR|primary|simulated timeout
```

## 測試矩陣彙整（_tmp_summary）
```sql
all_random|backup|ERROR|6
gemini_dns|backup|OK|3
gemini_dns|primary|OK|3
gemini_timeout|backup|OK|4
gemini_timeout|primary|OK|2
groq_429|backup|OK|2
groq_429|primary|OK|4
groq_timeout|backup|OK|2
groq_timeout|primary|OK|4
none|primary|OK|6
```
