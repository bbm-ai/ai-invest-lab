# Day 18 — Failure Summary (last 24h)

## ERROR Types (head)
```
simulated timeout|76
simulated dns|22
groq simulated timeout|18
simulated 429|8
gemini simulated timeout|7
groq simulated 429|2
gemini simulated dns failure|2
Error code: 404 - {'error': {'message': 'The model `gpt-oss:20b` does not exist or you do not have access to it.', 'type|1
```

## By Provider (ERROR)
```
gemini|71
groq|65
```

## Recent ERROR rows (10)
```
2025-11-09 02:42:24|news_summary|groq|backup|simulated timeout
2025-11-09 02:42:24|strategy_synthesis|groq|backup|groq simulated timeout
2025-11-09 02:42:22|strategy_synthesis|gemini|primary|simulated timeout
2025-11-09 02:42:20|news_summary|groq|backup|simulated timeout
2025-11-09 02:42:20|tech_summary|groq|backup|groq simulated timeout
2025-11-09 02:42:18|tech_summary|gemini|primary|simulated timeout
2025-11-09 02:42:16|news_summary|gemini|backup|simulated timeout
2025-11-09 02:42:16|news_summary|gemini|backup|gemini simulated timeout
2025-11-09 02:42:14|news_summary|groq|primary|simulated timeout
2025-11-09 02:42:12|news_summary|groq|backup|simulated timeout
```
