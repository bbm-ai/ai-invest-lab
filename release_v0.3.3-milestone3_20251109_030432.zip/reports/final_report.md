# Final Project Report

_Generated at: 2025-11-09T01:13:23_

## 1. 總覽
- 自動化：Systemd + Cron（ET 17:05）
- DB：SQLite（prices/news/sentiments/tech_signals/strategies/llm_costs）
- 路由：Groq/Gemini + Claude（策略性升級）
- 儀表板：Streamlit（Mobile-friendly）

## 2. LLM Routing & Cost（近 7 天）

| Day | Provider | Calls | OK | ERROR | SKIP |
|---|---|---:|---:|---:|---:|
| 2025-11-09 | claude | 8 | 0 | 0 | 8 |
| 2025-11-09 | gemini | 237 | 70 | 71 | 96 |
| 2025-11-09 | groq | 169 | 57 | 64 | 48 |
| 2025-11-08 | gemini | 5 | 3 | 0 | 2 |
| 2025-11-08 | groq | 2 | 0 | 1 | 1 |

### 24h Route mix

| Route | Count |
|---|---:|
| primary | 306 |
| backup | 107 |
| escalated | 8 |

### 24h Error samples

| Error(head) | Count |
|---|---:|
| simulated timeout | 76 |
| simulated dns | 22 |
| groq simulated timeout | 18 |
| simulated 429 | 8 |
| gemini simulated timeout | 7 |
| groq simulated 429 | 2 |
| gemini simulated dns failure | 2 |
| Error code: 404 - {'error': {'message': 'The model `gpt-oss: | 1 |

## 3. Strategies（近 7 天）

| Date | Symbol | Rec | Size | Conf |
|---|---|---|---:|---:|
| 2025-11-08 | DIA | HOLD | 0.00 | 0.59 |
| 2025-11-08 | QQQ | BUY | 1.00 | 0.59 |
| 2025-11-08 | SPY | HOLD | 0.00 | 0.59 |

## 4. 回測/報表附件

- backtest_readout.md
- m2_costs_last7d.md

## 5. 設定快照（config.yaml）
```yaml

investment:
  symbols: ["SPY"]

schedule:
  timezone: "America/New_York"
  strategy: "0 17 * * 1-5"
  data_collection: "0 */4 * * *"
  backup: "0 2 * * *"

router:
  enable_claude: true     # 預設關閉；要測試 Claude 時設 true
  claude_model: "claude-sonnet-4-5-20250929"

policy:
  min_conf_for_no_escalation: 0.80
  sentiment_extreme: 0.10
  daily_claude_call_cap: 2




```

## 6. 既知事項與後續 Roadmap
- （示例）完善策略版本管理與滾動回測
- （示例）Streamlit 登入與角色分權
- （示例）雲端冷備份（GCS/S3）
- （示例）任務級重試與可觀測性（OpenTelemetry / traces）
